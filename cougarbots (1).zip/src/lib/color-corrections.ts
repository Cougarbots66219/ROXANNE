import { supabase } from "@/integrations/supabase/client";
import { CREATURES, LIGHTS, type Creature, type Light, type Example, type Sample } from "./color-learning";

export function mergeCorrectedSamples(samples: Sample[], correctedIds: Set<string>): Sample[] {
  const corrections = samples.filter(s => correctedIds.has(s.id));
  const same = (a: number[], b: number[]) => a.length === b.length && a.every((v, i) => Math.abs(v - (b[i] ?? Infinity)) < 1e-7);
  return samples.filter(s => correctedIds.has(s.id) || !corrections.some(c => same(s.features.light, c.features.light) && same(s.features.creature, c.features.creature)));
}

export async function loadCorrections(): Promise<Example[]> {
  const rows: Example[] = [];
  for (let offset = 0; ; offset += 100) {
    const { data, error } = await supabase.from("color_corrections").select("id,image_path,light,creature,is_public").order("created_at").order("id").range(offset, offset + 99);
    if (error) throw new Error("Saved photos could not be loaded. Please try again.");
    for (const row of data) {
      const signed = await supabase.storage.from(row.is_public ? "color-contributions" : "color-corrections").createSignedUrl(row.image_path, 3600);
      if (signed.error) throw new Error("A saved photo could not be opened. Please try again.");
      rows.push({ id: row.id, url: signed.data.signedUrl, light: row.light as Light, creature: row.creature as Creature });
    }
    if (data.length < 100) return rows;
  }
}

export async function saveCorrection(url: string, light: Light, creature: Creature): Promise<Example> {
  if (!LIGHTS.includes(light) || !CREATURES.includes(creature)) throw new Error("Choose both actual colors.");
  const { data: { user }, error: authError } = await supabase.auth.getUser();
  if (authError || !user) throw new Error("Sign in to save your corrected photo.");
  const response = await fetch(url);
  if (!response.ok) throw new Error("This photo could not be opened. Upload it again.");
  const blob = await response.blob();
  if (!blob.type.startsWith("image/") || blob.size > 5 * 1024 * 1024) throw new Error("Use an image smaller than 5 MB.");
  const hash = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", await blob.arrayBuffer())), b => b.toString(16).padStart(2, "0")).join("");
  const path = `${user.id}/${hash}.jpg`;
   const { data: existing, error: readError } = await supabase.from("color_corrections").select("id,is_public").eq("user_id", user.id).eq("image_hash", hash).maybeSingle();
  if (readError) throw new Error("Your saved photos could not be checked. Please try again.");
   if (!existing?.is_public) {
     const upload = await supabase.storage.from("color-contributions").upload(path, blob, { contentType: blob.type });
    if (upload.error && upload.error.message !== "The resource already exists") throw new Error("Photo upload failed. Please try again.");
  }
   const { data, error } = await supabase.from("color_corrections").upsert({ user_id: user.id, image_hash: hash, image_path: path, light, creature, is_public: true }, { onConflict: "user_id,image_hash" }).select("id").single();
  if (error) throw new Error("The colors could not be saved. Please try again.");
   const signed = await supabase.storage.from("color-contributions").createSignedUrl(path, 3600);
  if (signed.error) throw new Error("Colors saved, but the photo could not be reopened. Please reload.");
  return { id: data.id, url: signed.data.signedUrl, light, creature };
}