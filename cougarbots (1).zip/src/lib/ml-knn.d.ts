declare module "ml-knn" {
  export default class KNN {
    constructor(data: number[][], labels: string[], options?: { k?: number });
    predict(data: number[][]): string[];
  }
}