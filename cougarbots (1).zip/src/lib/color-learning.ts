import KNN from "ml-knn";

export const LIGHTS = ["White", "Red", "Green", "Blue", "Violet", "Orange", "Yellow"] as const;
export const CREATURES = ["Clear", "Red", "Yellow", "Blue", "Green", "Orange", "Purple", "Black", "White"] as const;
export type Light = typeof LIGHTS[number];
export type Creature = typeof CREATURES[number];
export type Example = { id: string; url: string; light: Light; creature: Creature };
export type Features = { light: number[]; creature: number[] };
export type Sample = Example & { features: Features };
export type Prediction = { light: Light; creature: Creature; lightConfidence: number; creatureConfidence: number };

// Robust quantiles suppress reflections and background LEDs. Chromaticity helps
// illumination stay stable across exposure; a tighter center isolates creature color.
export function extractFeatures(rgba: ArrayLike<number>, width: number, height: number): Features {
  const regions: number[][][] = [[], []];
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const offset = (y * width + x) * 4;
    const r = (rgba[offset] ?? 0) / 255, g = (rgba[offset + 1] ?? 0) / 255, b = (rgba[offset + 2] ?? 0) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
    if (max < 0.07) continue;
    let hue = delta === 0 ? 0 : max === r ? ((g - b) / delta + 6) % 6 : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4;
    hue /= 6;
    const saturation = max === 0 ? 0 : delta / max;
    const total = r + g + b + .001;
    const pixel = [hue, r / total, g / total, b / total, r, g, b, saturation, max];
    if (x > width * .22 && x < width * .78 && y > height * .15 && y < height * .85) regions[0]?.push(pixel);
    if (x > width * .3 && x < width * .7 && y > height * .2 && y < height * .7) regions[1]?.push(pixel);
  }
  function summarize(pixels: number[][]) {
    const histogram = new Array<number>(19).fill(0);
    for (const pixel of pixels) {
      const bin = (pixel[7] ?? 0) < .15 ? 18 : Math.min(17, Math.floor((pixel[0] ?? 0) * 18));
      histogram[bin] = (histogram[bin] ?? 0) + 1;
    }
    const values = histogram.map(value => Math.sqrt(value / Math.max(1, pixels.length)));
    for (let channel = 1; channel <= 8; channel++) {
      const sorted = pixels.map(pixel => pixel[channel] ?? 0).sort((a, b) => a - b);
      for (const q of [.1, .25, .5, .75, .9]) {
        const index = Math.max(0, sorted.length - 1) * q;
        const low = sorted[Math.floor(index)] ?? 0, high = sorted[Math.ceil(index)] ?? 0;
        values.push(low + (high - low) * (index % 1));
      }
    }
    return values;
  }
  return {
    light: summarize(regions[0] ?? []).map((v, i) => v * ((i >= 34 && i < 49) || i >= 54 ? .3 : 1)),
    creature: summarize(regions[1] ?? []),
  };
}

export function readFeatures(image: CanvasImageSource): Features {
  const canvas = document.createElement("canvas");
  canvas.width = 96; canvas.height = 96;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("Photo analysis is unavailable in this browser.");
  context.drawImage(image, 0, 0, 96, 96);
  return extractFeatures(context.getImageData(0, 0, 96, 96).data, 96, 96);
}

export async function loadPhoto(url: string): Promise<HTMLImageElement> {
  const image = new Image(); image.crossOrigin = "anonymous";
  image.src = url;
  await image.decode();
  return image;
}

export function trainColorModel(samples: Sample[]) {
  if (samples.length < 3) throw new Error("Add at least three training photos.");
  if (samples.some(s => ![...s.features.light, ...s.features.creature].every(Number.isFinite))) throw new Error("Training photos contain invalid color measurements.");
  const lightModel = new KNN(samples.map(s => s.features.light), samples.map(s => s.light), { k: 1 });
  const models = new Map<Light, KNN>();
  for (const light of LIGHTS) {
    const group = samples.filter(s => s.light === light);
    if (group.length) models.set(light, new KNN(group.map(s => s.features.creature), group.map(s => s.creature), { k: 1 }));
  }
  const lightConfidence = confidenceEstimator(samples.map(s => ({ label: s.light, values: s.features.light })), LIGHTS.length);
  const creatureConfidence = new Map(LIGHTS.map(light => [light, confidenceEstimator(samples.filter(s => s.light === light).map(s => ({ label: s.creature, values: s.features.creature })), CREATURES.length)]));
  return {
    predict(features: Features): Prediction {
      const light = lightModel.predict([features.light])[0] as Light | undefined;
      if (!light) throw new Error("Unable to identify the light.");
      const model = models.get(light);
      const creature = model?.predict([features.creature])[0] as Creature | undefined;
      if (!creature) throw new Error("No creature examples for this light.");
      return { light, creature, lightConfidence: lightConfidence(features.light, light), creatureConfidence: creatureConfidence.get(light)?.(features.creature, creature) ?? 0 };
    },
  };
}

// Similarity support, NOT a calibrated probability: nearest-label margin, distance
// from the training distribution, and available class coverage each limit the score.
function confidenceEstimator(rows: { label: string; values: number[] }[], expectedClasses: number) {
  const distance = (a: number[], b: number[]) => Math.sqrt(a.reduce((sum, value, i) => sum + (value - (b[i] ?? 0)) ** 2, 0));
  const nearest = rows.map((row, i) => Math.min(...rows.filter((_, j) => i !== j).map(other => distance(row.values, other.values)))).filter(Number.isFinite).sort((a, b) => a - b);
  const scale = Math.max(.001, nearest[Math.floor(nearest.length / 2)] ?? .001);
  const coverage = new Set(rows.map(row => row.label)).size / expectedClasses;
  return (values: number[], label: string) => {
    const same = Math.min(...rows.filter(row => row.label === label).map(row => distance(values, row.values)));
    const other = Math.min(...rows.filter(row => row.label !== label).map(row => distance(values, row.values)));
    const margin = Number.isFinite(other) ? other / Math.max(.000001, same + other) : .5;
    return Math.min(.99, Math.max(0, margin * Math.exp(-same / (3 * scale)) * coverage));
  };
}

export function evaluateColorModel(samples: Sample[], grouped = false) {
  let lightCorrect = 0, creatureCorrect = 0, bothCorrect = 0, evaluated = 0;
  // Filename timestamps provide a conservative early/late capture-session check.
  const group = (s: Sample) => s.id.match(/(?:^|-)(\d{8})_(\d{2})/)?.slice(1).join("-") ?? s.id;
  for (const sample of samples) {
    const training = samples.filter(other => grouped ? group(other) !== group(sample) : other.id !== sample.id);
    if (training.length < 3) continue;
    const prediction = trainColorModel(training).predict(sample.features);
    evaluated++;
    if (prediction.light === sample.light) lightCorrect++;
    if (prediction.creature === sample.creature) creatureCorrect++;
    if (prediction.light === sample.light && prediction.creature === sample.creature) bothCorrect++;
  }
  return { lightCorrect, creatureCorrect, bothCorrect, evaluated };
}