import { useEffect, useRef, useState } from "react";
import { Camera, Upload, Play, Square, Plus, Check, LoaderCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import labels from "@/assets/training-labels.json";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useCameraInput } from "@/hooks/use-camera-input";
import { loadCorrections, saveCorrection, mergeCorrectedSamples } from "@/lib/color-corrections";
import { CREATURES, LIGHTS, loadPhoto, readFeatures, trainColorModel, evaluateColorModel, type Prediction, type Example, type Sample, type Creature, type Light } from "@/lib/color-learning";

const initialExamples = labels as Example[];
type Model = ReturnType<typeof trainColorModel>;
export function ColorLab() {
  const [examples, setExamples] = useState<Example[]>(initialExamples);
  const [model, setModel] = useState<Model>();
  const [training, setTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [light, setLight] = useState<Light>("Red");
  const [creature, setCreature] = useState<Creature>("Clear");
  const [photo, setPhoto] = useState("");
  const [result, setResult] = useState<Prediction>();
  const [busy, setBusy] = useState(false);
  const cameraInput = useCameraInput();
  const camera = cameraInput.active;
  const [evaluation, setEvaluation] = useState("");
  const [actualLight, setActualLight] = useState<Light | "">("");
  const [actualCreature, setActualCreature] = useState<Creature | "">("");
  const [saving, setSaving] = useState(false);
  const [savedMessage, setSavedMessage] = useState("");
  const [signedIn, setSignedIn] = useState(false);
  const [loadingSaved, setLoadingSaved] = useState(true);
  const correctedIds = useRef(new Set<string>());
  const identity = useRef<string | undefined>(undefined);
  const video = useRef<HTMLVideoElement>(null);
  const urls = useRef<string[]>([]);
  const addInput = useRef<HTMLInputElement>(null);
  const testInput = useRef<HTMLInputElement>(null);
  useEffect(() => () => { urls.current.forEach(u => URL.revokeObjectURL(u)); }, []);
  useEffect(() => { if (camera && video.current && cameraInput.stream) { video.current.srcObject = cameraInput.stream; void video.current.play().catch(() => {}); } }, [camera, cameraInput.stream]);
  const fail = (e: unknown) => setError(e instanceof Error ? e.message : "Something went wrong. Please try again.");
  useEffect(() => {
    let active = true;
    async function sync(userId?: string) {
      if (!active) return;
      setSignedIn(Boolean(userId));
      if (identity.current === userId && !loadingSaved) return;
      identity.current = userId;
      setLoadingSaved(true); setModel(undefined); setResult(undefined); setEvaluation("");
      correctedIds.current.clear(); setExamples(initialExamples);
      try {
        const saved = await loadCorrections();
        if (!active || identity.current !== userId) return;
        correctedIds.current = new Set(saved.map(s => s.id));
        setExamples([...initialExamples, ...saved]);
      } catch (e) { if (active) fail(e); }
      finally { if (active && identity.current === userId) setLoadingSaved(false); }
    }
    void supabase.auth.getSession().then(({ data }) => sync(data.session?.user.id));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" || event === "SIGNED_OUT") setTimeout(() => void sync(session?.user.id), 0);
    });
    return () => { active = false; subscription.unsubscribe(); };
  }, []);
  async function train(rows = examples, keepResult = false) {
    setTraining(true); setError(""); setProgress(0); if (!keepResult) setResult(undefined);
    try {
      const measured: Sample[] = [];
      for (const example of rows) {
        measured.push({ ...example, features: readFeatures(await loadPhoto(example.url)) });
        setProgress(measured.length);
      }
      const samples = mergeCorrectedSamples(measured, correctedIds.current);
      const photoCheck = evaluateColorModel(samples);
      const sessionCheck = evaluateColorModel(samples, true);
      setEvaluation(`Photo-held-out: light ${photoCheck.lightCorrect}/${photoCheck.evaluated}; creature ${photoCheck.creatureCorrect}/${photoCheck.evaluated}; both ${photoCheck.bothCorrect}/${photoCheck.evaluated}. Capture-session-held-out: light ${sessionCheck.lightCorrect}/${sessionCheck.evaluated}; creature ${sessionCheck.creatureCorrect}/${sessionCheck.evaluated}; both ${sessionCheck.bothCorrect}/${sessionCheck.evaluated}. Measurements were refined on these photos; neither check guarantees accuracy on new scenes.`);
      const trained = trainColorModel(samples);
      setModel(trained);
      return trained;
    } catch (e) { fail(e); return undefined; } finally { setTraining(false); }
  }
  async function identify(url: string) {
    if (!model) return;
    setPhoto(url); setResult(undefined); setActualLight(""); setActualCreature(""); setSavedMessage(""); setBusy(true); setError("");
    try { setResult(model.predict(readFeatures(await loadPhoto(url)))); } catch (e) { fail(e); } finally { setBusy(false); }
  }
  function objectUrl(file: File) { const url = URL.createObjectURL(file); urls.current.push(url); return url; }
  async function learnActualColors() {
    if (!photo || !actualLight || !actualCreature || saving) return;
    setSaving(true); setError(""); setSavedMessage("");
    try {
      const saved = await saveCorrection(photo, actualLight, actualCreature);
      correctedIds.current.add(saved.id);
      const rows = [...examples.filter(e => e.id !== saved.id), saved];
      setExamples(rows);
      const updated = await train(rows, true);
      if (!updated) { setSavedMessage("Photo and actual colors saved. Retrain to use them in predictions."); return; }
      setResult(updated.predict(readFeatures(await loadPhoto(photo))));
      setSavedMessage("Shared and learned. Everyone can now train with this photo and its actual colors.");
    } catch (e) { fail(e); } finally { setSaving(false); }
  }
  async function signIn(provider: "google" | "lovable") {
    setError("");
    try { const response = await lovable.auth.signInWithOAuth(provider, { redirect_uri: `${window.location.origin}/color-lab` }); if (response.error) fail(response.error); }
    catch (e) { fail(e); }
  }
  async function startCamera() {
    setError("");
    try { await cameraInput.start(); } catch (e) { fail(e); }
  }
  function stopCamera() { cameraInput.stop(); }
  function capture() {
    if (!video.current || !model) return;
    const canvas = document.createElement("canvas"); canvas.width = video.current.videoWidth; canvas.height = video.current.videoHeight;
    const context = canvas.getContext("2d"); if (!context || !canvas.width) return;
    context.drawImage(video.current, 0, 0); void identify(canvas.toDataURL("image/jpeg")); stopCamera();
  }
  const visible = examples.filter(e => e.creature === creature);
  return <div className="space-y-10">
    <div className="flex flex-wrap items-center gap-3 text-sm">
      {signedIn ? <><span className="text-muted-foreground">Community contributions + your private photos</span><Button variant="ghost" disabled={saving || training} onClick={() => void supabase.auth.signOut().then(({ error }) => { if (error) fail(error); })}>Sign out</Button></> : <><Button variant="outline" onClick={() => void signIn("google")}>Sign in with Google</Button><Button variant="outline" onClick={() => void signIn("lovable")}>Continue with Lovable</Button></>}
    </div>
    <div className="flex flex-wrap items-center gap-3 border-y border-border py-4 text-sm">
      <span className="font-bold">{examples.length} training photos</span><span className="text-muted-foreground">{new Set(examples.map(e => e.creature)).size} trained creature colors · {LIGHTS.length} light colors</span>
      <span className="ml-auto flex items-center gap-2 text-accent"><span className="h-2 w-2 rounded-full bg-accent" />{model ? "Model ready" : "Not trained"}</span>
    </div>
    <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr]">
      <section className="min-w-0">
        <h2 className="text-2xl font-bold">01 / Training photos</h2>
        <div className="mt-5 flex flex-wrap gap-2" role="tablist" aria-label="Creature training colors">{CREATURES.map(c => <Button key={c} role="tab" aria-selected={c === creature} variant={c === creature ? "default" : "outline"} onClick={() => setCreature(c)}>{c}<span className="opacity-70">{examples.filter(e => e.creature === c).length}</span></Button>)}</div>
        <div className="mt-4 grid max-h-[380px] grid-cols-3 gap-3 overflow-y-auto pr-1 sm:grid-cols-4">
          {visible.map(e => <div key={e.id} className="overflow-hidden rounded-md border border-border bg-card">
            <img src={e.url} alt={`${e.creature} creature under ${e.light.toLowerCase()} light`} className="aspect-square w-full object-cover" loading="lazy" />
            <select aria-label={`Light label for ${e.id}`} value={e.light} disabled={training} className="w-full bg-card p-2 text-xs text-foreground" onChange={event => { setExamples(rows => rows.map(row => row.id === e.id ? { ...row, light: event.target.value as Light } : row)); setModel(undefined); setEvaluation(""); }}>{LIGHTS.map(l => <option key={l}>{l}</option>)}</select>
          </div>)}
        </div>
        <div className="mt-5 flex flex-wrap items-end gap-3">
          <label className="flex flex-col gap-2 text-xs text-muted-foreground">Light label<select className="h-9 rounded-md border border-input bg-background px-3 text-sm text-foreground" value={light} onChange={e => setLight(e.target.value as Light)}>{LIGHTS.map(l => <option key={l}>{l}</option>)}</select></label>
          <Button variant="outline" disabled={training} onClick={() => addInput.current?.click()}><Plus />Add {creature.toLowerCase()} photos</Button>
          <input ref={addInput} type="file" accept="image/*" multiple className="hidden" aria-label="Add training photos" onChange={event => { const files = Array.from(event.target.files ?? []).filter(f => f.type.startsWith("image/")); setExamples(rows => [...rows, ...files.map(file => ({ id: crypto.randomUUID(), url: objectUrl(file), light, creature }))]); setModel(undefined); setEvaluation(""); event.target.value = ""; }} />
        </div>
        <Button className="mt-6 w-full" size="lg" onClick={() => void train()} disabled={training || saving || loadingSaved}>{training ? <LoaderCircle className="animate-spin" /> : model ? <Check /> : <Play />}{loadingSaved ? "Loading saved photos…" : training ? `Training ${progress}/${examples.length}` : model ? "Retrain model" : "Train model"}</Button>
        <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Light labels were assigned from photo appearance and can be corrected. White means neutral illumination; Clear is the creature’s color. Added photos stay in this tab only.</p>
        {evaluation && <p className="mt-3 text-xs leading-relaxed text-muted-foreground" role="status">{evaluation}</p>}
      </section>
      <section className="min-w-0">
        <h2 className="text-2xl font-bold">02 / Identify a creature</h2>
        <div className="relative mt-5 flex aspect-[4/3] items-center justify-center overflow-hidden rounded-md border border-border bg-card">
          {camera ? <video ref={video} muted playsInline className="h-full w-full object-contain" /> : photo ? <img src={photo} alt="Photo being identified" className="h-full w-full object-contain" /> : <Camera className="h-12 w-12 text-muted-foreground" />}
          {busy && <LoaderCircle className="absolute h-8 w-8 animate-spin text-primary" />}
        </div>
        <div className="mt-4 flex flex-wrap gap-3">
          <Button disabled={!model || busy || training} onClick={() => testInput.current?.click()}><Upload />Upload photo</Button>
          <Button variant="outline" disabled={!model || busy || training || cameraInput.starting} onClick={() => camera ? capture() : void startCamera()}>{cameraInput.starting ? <LoaderCircle className="animate-spin" /> : <Camera />}{cameraInput.starting ? "Opening camera…" : camera ? "Capture & identify" : "Use camera"}</Button>
          {(camera || cameraInput.starting) && <Button variant="ghost" size="icon" aria-label="Stop camera" onClick={stopCamera}><Square /></Button>}
          <input ref={testInput} className="hidden" type="file" accept="image/*" aria-label="Upload photo to identify" onChange={e => { const file = e.target.files?.[0]; if (file) void identify(objectUrl(file)); e.target.value = ""; }} />
        </div>
        {cameraInput.inputs.length > 0 && <label className="mt-4 flex min-w-0 flex-col gap-2 text-xs text-muted-foreground">Camera input<select aria-label="Camera input" value={cameraInput.selected} disabled={cameraInput.starting || busy} className="h-10 w-full min-w-0 rounded-md border border-input bg-background px-3 text-sm text-foreground" onChange={event => { setError(""); void cameraInput.select(event.target.value).catch(fail); }}><option value="">Default camera</option>{cameraInput.inputs.map((input, index) => <option key={input.deviceId || index} value={input.deviceId}>{input.label || `Camera ${index + 1}`}</option>)}</select></label>}
        <div className="mt-6 grid grid-cols-[1fr_auto_1fr] items-center gap-3 border-y border-border py-5" aria-live="polite">
          <div><p className="text-xs font-bold uppercase text-muted-foreground">1 · Light color</p><p className="mt-2 text-2xl font-bold text-accent">{result?.light ?? "—"}</p>{result && <Confidence value={result.lightConfidence} label="Light" />}</div><ArrowRight className="h-5 w-5 text-muted-foreground" /><div><p className="text-xs font-bold uppercase text-muted-foreground">2 · Creature color</p><p className="mt-2 text-2xl font-bold text-primary">{result?.creature ?? "—"}</p>{result && <Confidence value={result.creatureConfidence} label="Creature" />}</div>
        </div>
        {photo && !camera && <section className="mt-6 space-y-4 border-b border-border pb-6">
          <h3 className="text-lg font-bold">03 / Actual colors</h3>
          <div className="grid grid-cols-2 gap-3">
            <label className="space-y-2 text-xs text-muted-foreground"><span>Actual light color</span><select aria-label="Actual light color" disabled={saving} value={actualLight} onChange={e => { setActualLight(e.target.value as Light | ""); setSavedMessage(""); }} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"><option value="">Choose light</option>{LIGHTS.map(l => <option key={l}>{l}</option>)}</select></label>
            <label className="space-y-2 text-xs text-muted-foreground"><span>Actual creature color</span><select aria-label="Actual creature color" disabled={saving} value={actualCreature} onChange={e => { setActualCreature(e.target.value as Creature | ""); setSavedMessage(""); }} className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm text-foreground"><option value="">Choose creature</option>{CREATURES.map(c => <option key={c}>{c}</option>)}</select></label>
          </div>
          <p className="text-xs text-muted-foreground">New contributions are public: your photo and actual-color labels will be visible to everyone and included in their training. Only share photos you have permission to publish. Previously private photos remain private unless shared again.</p>
          {signedIn ? <Button disabled={!actualLight || !actualCreature || saving || busy || training} onClick={() => void learnActualColors()}>{saving ? <LoaderCircle className="animate-spin" /> : <Plus />}{saving ? "Sharing and learning…" : "Share colors & learn"}</Button> : <div className="flex flex-wrap gap-2"><Button onClick={() => void signIn("google")}>Sign in with Google</Button><Button variant="outline" onClick={() => void signIn("lovable")}>Continue with Lovable</Button></div>}
          {savedMessage && <p role="status" className="text-sm text-accent">{savedMessage}</p>}
        </section>}
        {result && <p className="mt-3 text-xs leading-relaxed text-muted-foreground">Confidence measures photo similarity and competing colors, not the probability of being correct. Creature confidence assumes the light prediction is correct. Experimental results from model creatures, not verified biological identifications.</p>}
      </section>
    </div>
    {error && <p role="alert" className="rounded-md border border-destructive p-4 text-destructive">{error}</p>}
  </div>;
}

function Confidence({ value, label }: { value: number; label: string }) {
  const percent = Math.round(value * 100);
  return <div className="mt-3 space-y-2"><p className="text-xs text-muted-foreground">{percent}% confidence · {percent < 50 ? "Low" : percent < 80 ? "Moderate" : "High"}</p><progress aria-label={`${label} confidence`} max={100} value={percent} className="h-1.5 w-full overflow-hidden rounded-sm [&::-webkit-progress-bar]:bg-muted [&::-webkit-progress-value]:bg-accent [&::-moz-progress-bar]:bg-accent" /></div>;
}