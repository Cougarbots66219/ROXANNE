import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Eye, EyeOff, Waves, Camera, Activity, Database, Fish, Lightbulb } from "lucide-react";
import hero from "@/assets/hero-roxanne.jpg";
import { ChevronLeft, ChevronRight } from "lucide-react";
import dumbo from "@/assets/animals/dumbo.jpg.asset.json";
import angler from "@/assets/animals/angler.jpg.asset.json";
import seatoad from "@/assets/animals/seatoad.jpg.asset.json";
import siph from "@/assets/animals/siph.jpg.asset.json";
import coral from "@/assets/animals/coral.jpg.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ROXANNE | Cougarbots Innovation Project 2026" },
      {
        name: "description",
        content:
          "Cougarbots' ROXANNE robot uses red light instead of white light to observe and monitor deep sea biodiversity without disturbing it.",
      },
      { property: "og:title", content: "ROXANNE | Cougarbots Deep Sea Biodiversity" },
      {
        property: "og:description",
         content: "Red Light Ocean Xploration And Novel Nautical Engine — watching deep sea life without scaring it away.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const ACRONYM = [
  ["R", "Red Light"],
  ["O", "Ocean"],
  ["X", "Xploration"],
  ["A", "And"],
  ["N", "Novel"],
  ["N", "Nautical"],
  ["E", "Engine"],
];

const ANIMALS = [
  { src: dumbo.url, name: "Dumbo octopus", sci: "Grimpoteuthis sp.", credit: "NOAA Okeanos Explorer" },
  { src: angler.url, name: "Goosefish (anglerfish)", sci: "Lophiodes sp.", credit: "NOAA Okeanos Explorer" },
  { src: seatoad.url, name: "Sea toad", sci: "Chaunacops coloratus", credit: "NOAA Okeanos Explorer" },
  { src: siph.url, name: "Physonect siphonophore", sci: "Siphonophorae", credit: "NOAA Okeanos Explorer" },
  { src: coral.url, name: "Deep sea coral garden", sci: "Sibelius Seamount", credit: "NOAA Office of Ocean Exploration" },
];

const RED_FACTS = [
  {
    title: "Red disappears first",
    text: "Seawater absorbs red wavelengths within the first few dozen metres, so animals living deep below almost never see it.",
  },
  {
    title: "Most deep sea eyes can't detect it",
    text: "Many species simply never evolved to see red light. To them, ROXANNE is nearly invisible.",
  },
  {
    title: "A sensitive camera can",
    text: "ROXANNE's low-light camera picks the red light up, so we see the animal clearly while it sees nothing at all.",
  },
];

function RedLightViewer() {
  const [idx, setIdx] = useState(0);
  const animal = ANIMALS[idx];
  if (!animal) return null;
  const go = (d: number) => setIdx((i) => (i + d + ANIMALS.length) % ANIMALS.length);
  return (
    <div className="grid gap-8 lg:grid-cols-[1.3fr_1fr] items-center">
      <div>
        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-border bg-background">
          <img
            key={animal.src}
            src={animal.src}
            alt={`${animal.name} photographed in the deep sea`}
            loading="lazy"
            className="h-full w-full object-cover transition-all duration-700 animate-in fade-in"
            style={{ filter: "brightness(1.1)" }}
          />
          <div className="absolute inset-0 mix-blend-color bg-light-red/30" />
          <span className="absolute left-4 top-4 rounded-full bg-background/80 px-3 py-1 text-xs font-bold uppercase tracking-widest">
            Viewing: Red light
          </span>
          <button aria-label="Previous animal" onClick={() => go(-1)} className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-background/80 p-2 hover:bg-secondary">
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button aria-label="Next animal" onClick={() => go(1)} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-background/80 p-2 hover:bg-secondary">
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
        <div className="mt-3 flex items-center justify-between gap-4">
          <div>
            <p className="font-bold">{animal.name} <span className="font-normal italic text-muted-foreground">· {animal.sci}</span></p>
            <p className="text-xs text-muted-foreground">Photo: {animal.credit} (public domain)</p>
          </div>
          <div className="flex gap-2">
            {ANIMALS.map((a, i) => (
              <button key={a.name} aria-label={`Show ${a.name}`} onClick={() => setIdx(i)} className={`h-2.5 w-2.5 rounded-full transition ${i === idx ? "bg-primary" : "bg-muted-foreground/40"}`} />
            ))}
          </div>
        </div>
      </div>
      <div>
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="text-2xl font-bold">Why red light?</h3>
          <p className="mt-2 text-sm">
            Disturbance to wildlife: <span className="font-bold text-light-green">Low</span>
          </p>
          <p className="mt-4 text-muted-foreground">
            ROXANNE never uses white light. She works in red — the one colour most deep sea animals can't see.
          </p>
        </div>
        <ul className="mt-6 space-y-4">
          {RED_FACTS.map((f) => (
            <li key={f.title} className="rounded-2xl border border-border bg-card p-5">
              <h4 className="font-bold text-primary">{f.title}</h4>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

const FEATURES = [
  { icon: Lightbulb, title: "Red light array", text: "Red LEDs instead of white lights, so ROXANNE can see animals that would normally flee." },
  { icon: Camera, title: "Low-light camera", text: "A sensitive camera captures clear footage under dim red light." },
  { icon: Activity, title: "Quiet movement", text: "Slow, gentle thrusters so ROXANNE doesn't stir up sediment or startle animals." },
  { icon: Database, title: "Biodiversity log", text: "Every sighting is recorded with depth, time and light used so scientists can track change over time." },
];

function Index() {
  return (
    <main className="overflow-x-hidden">
      <nav aria-label="Main navigation" className="sticky top-0 z-20 border-b border-border bg-background/95">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-6 py-3">
          <Link to="/" className="font-display text-lg font-extrabold">ROXANNE</Link>
          <Button asChild><Link to="/color-lab"><Camera />Color Lab</Link></Button>
        </div>
      </nav>
      {/* Hero */}
      <section className="relative flex min-h-[620px] items-center py-16 md:min-h-[660px]">
        <img src={hero} alt="ROXANNE shining red light on deep sea jellyfish" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-transparent" />
        <div className="relative mx-auto w-full max-w-6xl px-6">
          <p className="text-sm font-bold uppercase tracking-[0.3em] text-primary">Cougarbots · Innovation Project · Biodiversity</p>
          <h1 className="mt-4 text-3xl font-extrabold sm:text-6xl md:text-8xl">ROXANNE</h1>
          <p className="mt-4 max-w-xl text-lg text-muted-foreground">
            <span className="text-foreground font-bold">R</span>ed{" "}
            Light{" "}
             <span className="text-foreground font-bold">O</span>cean <span className="text-foreground font-bold">X</span>ploration{" "}
            <span className="text-foreground font-bold">A</span>nd{" "}
            <span className="text-foreground font-bold">N</span>ovel{" "}
            <span className="text-foreground font-bold">N</span>autical{" "}
            <span className="text-foreground font-bold">E</span>ngine
          </p>
          <p className="mt-8 max-w-xl text-2xl md:text-3xl font-display font-bold leading-snug">
            How can we help better observe and monitor deep sea biodiversity?
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Button asChild size="lg"><Link to="/color-lab"><Camera />Open Color Lab</Link></Button>
            <Button asChild variant="outline" size="lg"><a href="#explorer"><Eye />See through ROXANNE's eyes</a></Button>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-secondary/40">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-6 px-6 py-12">
          <div>
            <p className="text-sm font-bold uppercase text-accent">Cougarbots / Color experiment</p>
            <h2 className="mt-3 text-3xl font-bold md:text-4xl">ROXANNE Color Lab</h2>
            <p className="mt-3 max-w-2xl text-muted-foreground">What color is the light — and what color is the creature underneath it?</p>
          </div>
          <Button asChild size="lg"><Link to="/color-lab"><Camera />Enter Color Lab</Link></Button>
        </div>
      </section>

      {/* Problem */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <p className="text-sm font-bold uppercase tracking-[0.3em] text-accent">The problem</p>
        <h2 className="mt-3 text-4xl md:text-5xl font-bold max-w-3xl">The deep sea is dark — and our lights get in the way.</h2>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            { icon: Waves, title: "Mostly unexplored", text: "The deep sea is the largest habitat on Earth, and most of its species have never been described." },
            { icon: EyeOff, title: "White light scares life away", text: "Bright lights on robots can make animals swim away or hide, so we miss them — and miscount them." },
            { icon: Fish, title: "Hard to monitor", text: "To protect biodiversity, scientists need to see how many animals live there and how that changes over time." },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="rounded-2xl border border-border bg-card p-6">
              <Icon className="h-8 w-8 text-primary" />
              <h3 className="mt-4 text-xl font-bold">{title}</h3>
              <p className="mt-2 text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Explorer */}
      <section id="explorer" className="relative py-24">
        <div className="absolute inset-0 bg-beam opacity-40" />
        <div className="relative mx-auto max-w-6xl px-6">
          <p className="text-sm font-bold uppercase tracking-[0.3em] text-primary">Our solution</p>
          <h2 className="mt-3 text-4xl md:text-5xl font-bold max-w-3xl">Red light lets us watch without being seen.</h2>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            ROXANNE works in red light instead of white. Scroll through real deep sea animals and see them the way she does.
          </p>
          <div className="mt-12">
            <RedLightViewer />
          </div>
        </div>
      </section>

      {/* Robot */}
      <section className="mx-auto max-w-6xl px-6 py-24">
        <p className="text-sm font-bold uppercase tracking-[0.3em] text-accent">Meet the robot</p>
        <h2 className="mt-3 text-4xl md:text-5xl font-bold">Inside ROXANNE</h2>
        <div className="mt-8 flex flex-wrap gap-3">
          {ACRONYM.map(([l, w], i) => (
            <div key={i} className="rounded-xl border border-border bg-card px-4 py-3 text-center">
              <div className="font-display text-3xl font-extrabold text-primary">{l}</div>
              <div className="text-xs text-muted-foreground">{w}</div>
            </div>
          ))}
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {FEATURES.map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex gap-4 rounded-2xl border border-border bg-card p-6">
              <Icon className="h-8 w-8 shrink-0 text-primary" />
              <div>
                <h3 className="text-xl font-bold">{title}</h3>
                <p className="mt-2 text-muted-foreground">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Impact */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="rounded-3xl border border-primary/40 bg-card p-10 md:p-16 text-center glow">
          <h2 className="text-3xl md:text-5xl font-bold">See more. Disturb less.</h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            By watching deep sea animals in their natural behavior, ROXANNE helps scientists count species more accurately,
            discover new ones, and notice when ecosystems start to change — so they can be protected.
          </p>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        Cougarbots · 2026 Season · Biodiversity Innovation Project
      </footer>
    </main>
  );
}
