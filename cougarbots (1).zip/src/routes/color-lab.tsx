import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ColorLab } from "@/components/color-lab";

export const Route = createFileRoute("/color-lab")({
  head: () => ({ meta: [
    { title: "ROXANNE Color Lab | Cougarbots" },
    { name: "description", content: "Train ROXANNE with Cougarbots photos to identify illumination first, then the creature's original color." },
    { property: "og:title", content: "ROXANNE Color Lab | Cougarbots" },
    { property: "og:description", content: "A two-stage color experiment using Cougarbots' creature photos under different lights." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: ColorLabPage,
});
function ColorLabPage() {
  return <main className="mx-auto max-w-6xl px-5 py-8 md:px-8 md:py-12">
    <Button asChild variant="ghost" className="mb-10"><Link to="/"><ArrowLeft />Back to ROXANNE</Link></Button>
    <p className="text-sm font-bold uppercase text-primary">Cougarbots / Color experiment</p>
    <h1 className="mt-3 text-4xl font-extrabold md:text-6xl">ROXANNE Color Lab</h1>
    <p className="mb-8 mt-4 text-lg text-muted-foreground">First the light. Then the creature.</p>
    <ColorLab />
  </main>;
}