import { describe, expect, it, vi } from "vitest";
vi.mock("@/integrations/supabase/client", () => ({ supabase: {} }));
import { mergeCorrectedSamples } from "@/lib/color-corrections";
import { trainColorModel, type Sample } from "@/lib/color-learning";

describe("Actual-color feedback", () => {
  const original: Sample = { id: "original", url: "fixture", light: "Red", creature: "Clear", features: { light: [0], creature: [0] } };
  const correction: Sample = { ...original, id: "corrected", light: "Blue", creature: "Yellow" };
  it("uses both actual colors in future predictions instead of contradictory original labels", () => {
    const rows = mergeCorrectedSamples([original, correction,
      { ...original, id: "other1", features: { light: [10], creature: [10] } },
      { ...original, id: "other2", features: { light: [20], creature: [20] } }], new Set(["corrected"]));
    expect(rows).toHaveLength(3);
    expect(trainColorModel(rows).predict(original.features)).toMatchObject({ light: "Blue", creature: "Yellow" });
  });
  it("keeps different photos and does not mutate original examples", () => {
    const rows = [original, { ...correction, features: { light: [1], creature: [1] } }];
    expect(mergeCorrectedSamples(rows, new Set(["corrected"]))).toHaveLength(2);
    expect(rows[0]?.creature).toBe("Clear");
  });
});