import { beforeEach, describe, expect, it, vi } from "vitest";
const api = vi.hoisted(() => ({ from: vi.fn(), bucket: vi.fn(), getUser: vi.fn() }));
vi.mock("@/integrations/supabase/client", () => ({ supabase: { from: api.from, storage: { from: api.bucket }, auth: { getUser: api.getUser } } }));
import { loadCorrections, saveCorrection } from "@/lib/color-corrections";

describe("Public image contributions", () => {
  beforeEach(() => vi.resetAllMocks());
  it("loads shared contributions without requiring a sign-in", async () => {
    const range = vi.fn().mockResolvedValue({ data: [{ id: "shared", image_path: "owner/hash.jpg", light: "Orange", creature: "Yellow", is_public: true }], error: null });
    const order = vi.fn(); order.mockReturnValue({ order, range });
    api.from.mockReturnValue({ select: vi.fn().mockReturnValue({ order }) });
    api.bucket.mockReturnValue({ createSignedUrl: vi.fn().mockResolvedValue({ data: { signedUrl: "shared-photo" }, error: null }) });
    expect(await loadCorrections()).toEqual([{ id: "shared", url: "shared-photo", light: "Orange", creature: "Yellow" }]);
    expect(api.bucket).toHaveBeenCalledWith("color-contributions");
    expect(api.getUser).not.toHaveBeenCalled();
  });
  it("keeps legacy private photos in their original bucket", async () => {
    const range = vi.fn().mockResolvedValue({ data: [{ id: "private", image_path: "owner/hash.jpg", light: "Red", creature: "Clear", is_public: false }], error: null });
    const order = vi.fn(); order.mockReturnValue({ order, range });
    api.from.mockReturnValue({ select: vi.fn().mockReturnValue({ order }) });
    api.bucket.mockReturnValue({ createSignedUrl: vi.fn().mockResolvedValue({ data: { signedUrl: "private-photo" }, error: null }) });
    await loadCorrections();
    expect(api.bucket).toHaveBeenCalledWith("color-corrections");
  });
  it("publishes new labels while checking duplicates only for the contributor", async () => {
    api.getUser.mockResolvedValue({ data: { user: { id: "owner" } }, error: null });
    const eq = vi.fn(); eq.mockReturnValue({ eq, maybeSingle: vi.fn().mockResolvedValue({ data: null, error: null }) });
    const upsert = vi.fn().mockReturnValue({ select: vi.fn().mockReturnValue({ single: vi.fn().mockResolvedValue({ data: { id: "shared" }, error: null }) }) });
    api.from.mockReturnValue({ select: vi.fn().mockReturnValue({ eq }), upsert });
    api.bucket.mockReturnValue({ upload: vi.fn().mockResolvedValue({ error: null }), createSignedUrl: vi.fn().mockResolvedValue({ data: { signedUrl: "public-photo" }, error: null }) });
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue({ ok: true, blob: async () => ({ type: "image/jpeg", size: 3, arrayBuffer: async () => new Uint8Array([1, 2, 3]).buffer }) } as Response);
    try {
      expect(await saveCorrection("photo", "Orange", "Yellow")).toMatchObject({ id: "shared", light: "Orange", creature: "Yellow" });
      expect(eq).toHaveBeenCalledWith("user_id", "owner");
      expect(upsert).toHaveBeenCalledWith(expect.objectContaining({ user_id: "owner", is_public: true, light: "Orange", creature: "Yellow" }), { onConflict: "user_id,image_hash" });
      expect(api.bucket).toHaveBeenCalledWith("color-contributions");
    } finally { fetchMock.mockRestore(); }
  });
});