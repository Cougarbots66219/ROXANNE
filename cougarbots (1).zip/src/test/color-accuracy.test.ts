import { describe, expect, it } from "vitest";
import { evaluateColorModel, type Sample } from "@/lib/color-learning";
import measurements from "./color-features.fixture.json";

// Browser-extracted measurements of the original 55 Asset photos; no images bundled.
// Development regression only, not an untouched estimate of new-scene accuracy.
describe("Supplied-photo accuracy regression", () => {
  it("improves combined held-out accuracy beyond the original 25/55", () => {
    const result = evaluateColorModel(measurements as Sample[]);
    expect(result.evaluated).toBe(55);
    expect(result.bothCorrect).toBeGreaterThan(25);
  });
  it("improves light recognition beyond the original 47/55", () => {
    expect(evaluateColorModel(measurements as Sample[]).lightCorrect).toBeGreaterThan(47);
  });
  it("improves creature recognition beyond the original 26/55", () => {
    expect(evaluateColorModel(measurements as Sample[]).creatureCorrect).toBeGreaterThan(26);
  });
  it("excludes every photo from the held-out timestamp session", () => {
    const rows: Sample[] = [
      { id: "Clear-20261025_160001.jpg", url: "fixture", light: "Red", creature: "Clear", features: { light: [0], creature: [0] } },
      { id: "Clear-20261025_160002.jpg", url: "fixture", light: "Red", creature: "Clear", features: { light: [0], creature: [0] } },
      ...[1, 2, 3].map(i => ({ id: `Red-20261025_17000${i}.jpg`, url: "fixture", light: "Blue" as const, creature: "Red" as const, features: { light: [10], creature: [10] } })),
    ];
    expect(evaluateColorModel(rows).bothCorrect).toBe(5);
    expect(evaluateColorModel(rows, true)).toEqual({ lightCorrect: 0, creatureCorrect: 0, bothCorrect: 0, evaluated: 2 });
  });
});