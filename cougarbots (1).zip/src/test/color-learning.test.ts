import { describe, expect, it } from "vitest";
import { extractFeatures, trainColorModel, type Sample } from "@/lib/color-learning";

function sample(id: string, light: Sample["light"], creature: Sample["creature"], l: number[], c: number[]): Sample {
  return { id, light, creature, url: "test", features: { light: l, creature: c } };
}
describe("Two-stage color recognition", () => {
  it.each(["Orange", "Yellow"] as const)("learns %s illumination before creature color", light => {
    const model = trainColorModel([
      sample("new", light, "Orange", [0], [0]),
      sample("same-light", light, "Yellow", [0], [5]),
      sample("other-light", "Red", "Clear", [10], [0]),
    ]);
    expect(model.predict({ light: [0], creature: [0] })).toMatchObject({ light, creature: "Orange" });
    expect(model.predict({ light: [0], creature: [5] })).toMatchObject({ light, creature: "Yellow" });
  });
  it("identifies light first and restricts creature recognition to that light", () => {
    const model = trainColorModel([
      sample("a", "Red", "Yellow", [0], [1]),
      sample("b", "Blue", "Clear", [10], [1]),
      sample("c", "Red", "Red", [0.1], [5]),
    ]);
    expect(model.predict({ light: [0.02], creature: [1] })).toMatchObject({ light: "Red", creature: "Yellow" });
    expect(model.predict({ light: [9.9], creature: [1] })).toMatchObject({ light: "Blue", creature: "Clear" });
  });
  it("preserves Clear, Red and Yellow as separate creature labels", () => {
    const model = trainColorModel([
      sample("a", "Red", "Clear", [0], [0]),
      sample("b", "Red", "Red", [0], [5]),
      sample("c", "Red", "Yellow", [0], [10]),
    ]);
    expect(model.predict({ light: [0], creature: [0] }).creature).toBe("Clear");
    expect(model.predict({ light: [0], creature: [5] }).creature).toBe("Red");
    expect(model.predict({ light: [0], creature: [10] }).creature).toBe("Yellow");
  });
  it.each(["Blue", "Green", "Orange", "Purple", "Black", "White"] as const)("learns an actual %s creature color under the identified light", color => {
    const model = trainColorModel([
      sample("new", "Red", color, [0], [0]),
      sample("clear", "Red", "Clear", [0], [5]),
      sample("other-light", "Blue", "Yellow", [10], [0]),
    ]);
    expect(model.predict({ light: [0], creature: [0] })).toMatchObject({ light: "Red", creature: color });
    expect(model.predict({ light: [10], creature: [0] }).creature).toBe("Yellow");
  });
  it("extracts distinct features from red and blue illumination", () => {
    const red = extractFeatures(Array(16).fill([255, 0, 0, 255]).flat(), 4, 4);
    const blue = extractFeatures(Array(16).fill([0, 0, 255, 255]).flat(), 4, 4);
    expect(red.light).not.toEqual(blue.light);
    expect(red.light.every(Number.isFinite)).toBe(true);
  });
  it("returns separate bounded confidence and reduces support for unfamiliar colors", () => {
    const model = trainColorModel([
      sample("a", "Red", "Clear", [0], [0]),
      sample("b", "Blue", "Red", [5], [5]),
      sample("c", "Green", "Yellow", [10], [10]),
    ]);
    const known = model.predict({ light: [0], creature: [0] });
    const unfamiliar = model.predict({ light: [100], creature: [100] });
    expect(known.lightConfidence).toBeGreaterThan(unfamiliar.lightConfidence);
    expect(known.creatureConfidence).toBeGreaterThan(unfamiliar.creatureConfidence);
    for (const result of [known, unfamiliar]) for (const confidence of [result.lightConfidence, result.creatureConfidence]) {
      expect(confidence).toBeGreaterThanOrEqual(0);
      expect(confidence).toBeLessThanOrEqual(.99);
    }
  });
  it("does not claim certainty with only one creature color under a light", () => {
    const model = trainColorModel([sample("a", "Red", "Clear", [0], [0]), sample("b", "Red", "Clear", [1], [1]), sample("c", "Red", "Clear", [2], [2])]);
    expect(model.predict({ light: [0], creature: [0] }).creatureConfidence).toBeLessThan(.5);
  });
});