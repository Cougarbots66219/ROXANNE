import { act, renderHook, waitFor } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import { useCameraInput } from "@/hooks/use-camera-input";

afterEach(() => vi.unstubAllGlobals());

it("switches to the chosen camera and releases previous and stopped inputs", async () => {
  const stopRear = vi.fn(); const stopFront = vi.fn();
  const rear = { getTracks: () => [{ stop: stopRear }], getVideoTracks: () => [{ getSettings: () => ({ deviceId: "rear" }) }] };
  const front = { getTracks: () => [{ stop: stopFront }], getVideoTracks: () => [{ getSettings: () => ({ deviceId: "front" }) }] };
  const getUserMedia = vi.fn().mockResolvedValueOnce(rear).mockResolvedValueOnce(front);
  vi.stubGlobal("navigator", { mediaDevices: { getUserMedia, enumerateDevices: vi.fn().mockResolvedValue([
    { kind: "videoinput", deviceId: "rear", label: "Rear camera" },
    { kind: "videoinput", deviceId: "front", label: "Front camera" },
    { kind: "audioinput", deviceId: "mic" },
  ]) } });
  const { result } = renderHook(() => useCameraInput());
  await act(async () => { await result.current.start(); });
  expect(result.current.selected).toBe("rear");
  expect(result.current.inputs).toHaveLength(2);
  await act(async () => { await result.current.select("front"); });
  expect(getUserMedia).toHaveBeenLastCalledWith({ video: { deviceId: { exact: "front" } }, audio: false });
  expect(stopRear).toHaveBeenCalledOnce();
  expect(result.current.stream).toBe(front);
  act(() => result.current.stop());
  expect(stopFront).toHaveBeenCalledOnce();
  expect(result.current.active).toBe(false);
});

it("releases a pending camera when the user stops before permission resolves", async () => {
  const stop = vi.fn();
  let resolve: ((value: unknown) => void) | undefined;
  const pending = new Promise(done => { resolve = done; });
  vi.stubGlobal("navigator", { mediaDevices: { getUserMedia: () => pending, enumerateDevices: async () => [] } });
  const { result } = renderHook(() => useCameraInput());
  let starting: Promise<void> | undefined;
  act(() => { starting = result.current.start(); });
  act(() => result.current.stop());
  await act(async () => { resolve?.({ getTracks: () => [{ stop }] }); await starting; });
  await waitFor(() => expect(stop).toHaveBeenCalledOnce());
  expect(result.current.active).toBe(false);
});