import { useEffect, useRef, useState } from "react";

export function useCameraInput() {
  const [active, setActive] = useState(false);
  const [starting, setStarting] = useState(false);
  const [inputs, setInputs] = useState<MediaDeviceInfo[]>([]);
  const [selected, setSelected] = useState("");
  const [stream, setStream] = useState<MediaStream>();
  const current = useRef<MediaStream | undefined>(undefined);
  const request = useRef(0);

  function stop() {
    request.current += 1;
    current.current?.getTracks().forEach(track => track.stop());
    current.current = undefined;
    setStream(undefined); setActive(false); setStarting(false);
  }

  async function start(deviceId = selected) {
    const devices = navigator.mediaDevices;
    if (!devices?.getUserMedia) throw new Error("Camera access is unavailable. Upload a photo instead.");
    stop();
    const token = request.current;
    setStarting(true);
    try {
      const next = await devices.getUserMedia({
        video: deviceId ? { deviceId: { exact: deviceId } } : { facingMode: "environment" },
        audio: false,
      });
      if (token !== request.current) { next.getTracks().forEach(track => track.stop()); return; }
      current.current = next;
      setStream(next); setActive(true);
      setSelected(next.getVideoTracks()[0]?.getSettings().deviceId ?? deviceId);
      // Labels become available after camera permission is granted.
      try {
        const available = await devices.enumerateDevices();
        if (token === request.current) setInputs(available.filter(device => device.kind === "videoinput"));
      } catch { /* A camera may still work when listing devices is unavailable. */ }
    } catch {
      if (token === request.current) throw new Error("Could not open this camera. Check camera permissions or choose another camera.");
    } finally {
      if (token === request.current) setStarting(false);
    }
  }

  useEffect(() => {
    const devices = navigator.mediaDevices;
    let mounted = true;
    const refresh = async () => {
      try {
        const available = await devices?.enumerateDevices();
        if (mounted && available) setInputs(available.filter(device => device.kind === "videoinput"));
      } catch { /* Permission is requested when the user opens the camera. */ }
    };
    void refresh();
    devices?.addEventListener?.("devicechange", refresh);
    return () => {
      mounted = false; request.current += 1;
      current.current?.getTracks().forEach(track => track.stop());
      devices?.removeEventListener?.("devicechange", refresh);
    };
  }, []);

  async function select(deviceId: string) {
    setSelected(deviceId);
    if (active) await start(deviceId);
  }

  return { active, starting, inputs, selected, stream, start, stop, select };
}