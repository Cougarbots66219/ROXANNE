<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the color experiment on its own TanStack content route, linked from the project page, to separate photo training from the deep-sea viewer.
- Color recognition trains browser-side nearest-neighbor models: illumination first, then a creature model conditioned on the predicted illumination; never represent its experimental outputs as verified biological identifications.
- Extract robust centered color quantiles and chromaticity for the two-stage model; report distance/margin/coverage confidence as similarity support, not calibrated probability, with photo and timestamp-session held-out checks to expose scene leakage.
- Uploaded training images use Lovable Asset pointers, with editable initial labels in a separate manifest, so media stays outside the source repository.
- Contributions use explicit public-read Cloud rows and a dedicated RLS-readable Storage bucket with signed URLs; legacy private corrections stay owner-only in their original bucket. Writes remain owner-scoped; load shared examples for signed-out visitors too, rebuild immediately after contributing, and override matching original measurements to avoid contradictory duplicate votes.
- Manage camera selection and stream lifecycle in a browser-only hook; release old tracks before switching and discard stale requests to prevent multiple active cameras.
