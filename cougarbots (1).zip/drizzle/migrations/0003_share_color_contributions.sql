ALTER TABLE public.color_corrections ADD COLUMN is_public boolean NOT NULL DEFAULT false;
GRANT SELECT (id, image_path, light, creature, created_at, is_public) ON public.color_corrections TO anon;
CREATE POLICY "Read shared contributions" ON public.color_corrections FOR SELECT TO anon, authenticated USING (is_public = true);
CREATE POLICY "Read shared contribution images" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'color-contributions' AND EXISTS (SELECT 1 FROM public.color_corrections c WHERE c.image_path = name AND c.is_public = true));
CREATE POLICY "Upload own shared contribution images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'color-contributions' AND (storage.foldername(name))[1] = auth.uid()::text AND storage.extension(name) = 'jpg');
CREATE POLICY "Delete own shared contribution images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'color-contributions' AND (storage.foldername(name))[1] = auth.uid()::text);
COMMENT ON COLUMN public.color_corrections.is_public IS 'Explicit shared contribution; legacy private corrections remain owner-only.';