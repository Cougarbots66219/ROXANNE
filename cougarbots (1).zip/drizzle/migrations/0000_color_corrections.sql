CREATE TABLE public.color_corrections (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 user_id uuid NOT NULL DEFAULT auth.uid(),
 image_hash text NOT NULL CHECK (image_hash ~ '^[a-f0-9]{64}$'),
 image_path text NOT NULL,
 light text NOT NULL CHECK (light IN ('White','Red','Green','Blue','Violet')),
 creature text NOT NULL CHECK (creature IN ('Clear','Red','Yellow')),
 created_at timestamptz NOT NULL DEFAULT now(),
 UNIQUE(user_id, image_hash),
 CHECK (image_path = user_id::text || '/' || image_hash || '.jpg')
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.color_corrections TO authenticated;
GRANT ALL ON public.color_corrections TO service_role;
ALTER TABLE public.color_corrections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Read own corrections" ON public.color_corrections FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Add own corrections" ON public.color_corrections FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Edit own corrections" ON public.color_corrections FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Delete own corrections" ON public.color_corrections FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Read own correction images" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'color-corrections' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "Upload own correction images" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'color-corrections' AND (storage.foldername(name))[1] = auth.uid()::text AND storage.extension(name) = 'jpg');
CREATE POLICY "Delete own correction images" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'color-corrections' AND (storage.foldername(name))[1] = auth.uid()::text);